"""
Train a diffusion model on images.
"""

import argparse
import json, os
import numpy as np
from transformers import set_seed
from improved_diffusion import dist_util, logger
from improved_diffusion.image_datasets import load_data
from improved_diffusion.text_datasets import load_data_text
from improved_diffusion.resample import create_named_schedule_sampler
from improved_diffusion.script_util import (
    model_and_diffusion_defaults,
    create_model_and_diffusion,
    args_to_dict,
    add_dict_to_argparser,
)
from transformers import AutoTokenizer
from improved_diffusion.train_util import TrainLoop

from functools import partial
from improved_diffusion.test_util import get_weights, compute_logp
from improved_diffusion.rounding import load_models, load_tokenizer
import torch.distributed as dist
import wandb
import torch

# Check if GPU is available
# pycharm已同步  1122
if torch.cuda.is_available():
    # Set the current GPU device to GPU 7
    print("GPU is available.")
    torch.cuda.device(6)
    device_idx = torch.cuda.current_device()
    device_name = torch.cuda.get_device_name(device_idx)
    print(f"Currently using GPU {device_idx}: {device_name}")
else:
    print("GPU is not available.")


def main():
    print('进入train')
    args = create_argparser().parse_args()  # 参数解析器，解析命令行输入的参数
    print('40')
    set_seed(args.seed)  # 函数设置随机数种子，以确保实验的可重复性
    print('42')
    dist_util.setup_dist()  # DEBUG **  设置分布式训练的环境
    print('44')
    logger.configure()  # 配置日志记录，用于记录训练过程中的信息。

    logger.log("creating model and diffusion...")
    import pdb
    pdb.set_trace()  # 进入调试模式
    print('开始创建')
    model, diffusion = create_model_and_diffusion(
        **args_to_dict(args, model_and_diffusion_defaults().keys())
    )
    print('创建完成')
    model.to(dist_util.dev())  # DEBUG ** 将模型移到指定的设备上
    # model.cuda() #  DEBUG **
    print('62')
    pytorch_total_params = sum(p.numel() for p in model.parameters())  # 统计模型的总参数量
    print('64')
    logger.log(f'the parameter count is {pytorch_total_params}')  # the parameter count is 87129749
    # 根据参数创建一个指定的调度采样器
    schedule_sampler = create_named_schedule_sampler(args.schedule_sampler, diffusion)
    print('68')
    logger.log(f'saving the hyperparameters to {args.checkpoint_path}/training_args.json')
    with open(f'{args.checkpoint_path}/training_args.json', 'w') as f:
        json.dump(args.__dict__, f, indent=2)  # 1.json.dumps将一个Python数据结构转换为JSON：
    # 初始化wandb（Weights & Biases），一个用于跟踪实验和可视化训练过程的工具
    wandb.init(
        project=os.getenv("WANDB_PROJECT", "diffusion_lm"),
        name=args.checkpoint_path,
    )
    # 这个地方是开始了wandb 开始选择什么东西
    wandb.config.update(args.__dict__, allow_val_change=True)
    # 条件数据加载（选择的下面这个if）
    # 用于指定数据的模态（数据的类型或形式，包括图像、文本、音频等）args.modality用于控制数据加载的方式，从而适配不同的数据模态。
    # 检查运行模式
    if args.experiment_mode == 'conditional_gen':
        print('满足第一个if，进入生成==这样的话值就是为pad')  # 根据运行命令应该是没进
        assert args.modality in ['e2e']
        # args.padding_mode用于控制数据加载时的填充方式。填充是处理不同长度的数据时常用的技术（处理文本数据），
        # 将长度不一致的句子都填充到相同长度，以便于放入一个批次中进行训练。
        # 如果args.padding_mode的值为'pad'，则表明数据加载时会采用填充的方式。
        assert args.padding_mode == 'pad'
    logger.log("creating data loader...")

    if args.modality == 'image':
        data = load_data(
            data_dir=args.data_dir,
            batch_size=args.batch_size,
            image_size=args.image_size,
            class_cond=args.class_cond,
        )
        data_valid = None

    # 进了下面这个else
    else:
        print('load data', '*' * 50)  # *************既不是image 也不是contrl
        if args.modality == 'roc-aug' or args.modality == 'commonGen-aug':
            print("进入第一个if103")
            # Tokenizer是自然语言处理中的一个重要组件，它用于将文本转换成模型可以处理的数字序列。
            # load_tokenizer函数根据指定的路径加载tokenizer，并将加载的结果存储在变量tokenizer中。
            tokenizer = load_tokenizer(args.modality, args.experiment,
                                       'predictability/diffusion_models_v7/diff_roc_pad_rand16_transformer_lr0.0001_0.0_2000_sqrt_Lsimple_h128_s2_d0.1_sd108_xstart')
            # 通过反转tokenizer，将原本的token到index的映射关系颠倒过来，变成index到token的映射关系，
            # 这样在模型输出的数字序列中，可以通过索引查找对应的token，从而得到文本形式的输出结果，更容易理解和解释模型的预测结果。
            rev_tokenizer = {v: k for k, v in tokenizer.items()}
            print(len(rev_tokenizer), 'loading from tokenizer. ')
        elif args.use_bert_tokenizer == 'yes':
            print("进入第二个if")
            rev_tokenizer = AutoTokenizer.from_pretrained('bert-base-uncased')
        else:
            print("进入else")  # 上面没进  进的这个
            rev_tokenizer = None  # 直接是默认0
        # 检查实验名称
        if args.experiment == 'random1':
            print("第二板块进入第一个if")
            args.experiment = 'random'
            print('loading from the vocabs here.')
            assert args.in_channel == 64
            assert args.modality == 'roc'
            model22 = torch.nn.Embedding(args.vocab_size, args.in_channel)
            model22_weight = torch.load('predictability/diffusion_models_v7/diff_roc-aug_pad_rand64_'
                                        'transformer_lr0.0001_0.0_2000_sqrt_Lsimple_h128_s2_d0.1_sd108_xstart_e2e/'
                                        'ema_0.9999_200000.pt', map_location='cpu')['word_embedding.weight']
            model22.weight = model22_weight
            model22.weight.requires_grad = False
        else:
            # 第二板块也是进入else
            print("第二板块进入else")
            model22 = None  # 直接为空

        data = load_data_text(
            data_dir=args.data_dir,
            batch_size=args.batch_size,
            image_size=args.image_size,
            class_cond=args.class_cond,
            data_args=args,
            task_mode=args.modality,
            padding_mode=args.padding_mode,  # block, pad
            load_vocab=rev_tokenizer,
            model=model22,  # 根据上面model22为空，为什么会为空？
        )
        # 在 load_data_text 函数中，返回了一个数据加载器（data loader）即data。
        # 数据加载器是一个可迭代对象，通过 next(data) 可以从数据加载器中获取下一个数据批次。
        next(data)  # next() 返回迭代器的下一个项目。next() 函数要和生成迭代器的 iter() 函数一起使用。在这里next函数加载text 数据集
        # 从train中加载 2974 821等等 next函数等会再详细的看
        import pdb
        pdb.set_trace()
        model2, tokenizer = load_models(args.modality, args.experiment, args.model_name_or_path, args.in_channel,
                                        args.checkpoint_path,
                                        extra_args=args)  # model2 ：Embedding(821, 16)  tokenizer是一个长度为821的字典
        print('模型加载完毕157')
        if args.modality == 'book' or args.use_bert_tokenizer == 'yes':
            rev_tokenizer = tokenizer  # BERT tokenizer BPE.
        else:
            rev_tokenizer = {v: k for k, v in tokenizer.items()}  # 是这个  rev_tokenizer就是tokenzier 821个字典
        print("运行到了151")
        data_valid = load_data_text(  # 没有仔细看，但返回了对象，看应该有输出，但命令行又没有显示输出
            data_dir=args.data_dir,
            batch_size=args.batch_size,
            image_size=args.image_size,
            class_cond=args.class_cond,
            data_args=args,
            task_mode=args.modality,
            padding_mode=args.padding_mode,  # block, pad
            split='valid',
            load_vocab=rev_tokenizer,
            model=model2,
        )
        print('164')

    # dist.barrier()
    # import time
    # while not os.path.exists(os.path.join(args.checkpoint_path, 'vocab.json')):
    #     time.sleep(1)
    def get_mapping_func(args, diffusion, data):
        print('171')
        model2, tokenizer = load_models(args.modality, args.experiment, args.model_name_or_path, args.in_channel,
                                        args.checkpoint_path,
                                        extra_args=args)  # 这个地方重复执行，前面已经获得model2 tokenizer的结果，又来了一次？
        model3 = get_weights(model2, args)
        print(model3, model3.weight.requires_grad)  # Embedding(821, 16) False  不梯度回传
        mapping_func = partial(compute_logp, args, model3.cuda())  # 这个partial函数出现了很多次partial是干嘛的 logp 是一个对计算结果做一个loss
        diffusion.mapping_func = mapping_func  # map() 会根据提供的函数对指定序列做映射。这里猜测是对应的数据做噪音处理
        return mapping_func

    get_mapping_func(args, diffusion, data)
    pdb.set_trace()
    logger.log("training...")

    # 下面开始打印不出
    # 训练循环的类，用于在训练过程中控制模型的训练和保存训练的中间检查点。
    TrainLoop(
        model=model,  # 训练的模型
        diffusion=diffusion,  # 所使用的扩散模型或技术
        data=data,  # 数据加载器，用于提供训练数据
        batch_size=args.batch_size,  # 批量大小，用于每次从数据加载器中获取的样本数目
        microbatch=args.microbatch,  # 是否使用微批量训练技术，即将每个批次进一步拆分成更小的批次进行训练，以减少内存占用
        lr=args.lr,  # 初始学习率
        ema_rate=args.ema_rate,  # 指数滑动平均率，用于计算滑动平均参数，以在训练中保持较为稳定的参数估计
        log_interval=args.log_interval,  # 每隔多少步打印一次训练日志
        save_interval=args.save_interval,  # 每隔多少步保存一次训练检查点
        resume_checkpoint=args.resume_checkpoint,  # 是否从之前的检查点中恢复训练
        use_fp16=args.use_fp16,  # 是否使用混合精度训练，即使用半精度浮点数（float16）进行计算，以提高训练速度
        fp16_scale_growth=args.fp16_scale_growth,  # 混合精度训练时的缩放增长因子
        schedule_sampler=schedule_sampler,  # 用于采样学习率和微批量大小的采样器
        weight_decay=args.weight_decay,  # 权重衰减，用于防止过拟合的正则化技术
        lr_anneal_steps=args.lr_anneal_steps,  # 学习率退火的步数，即在训练过程中学习率逐渐减小
        checkpoint_path=args.checkpoint_path,  # 检查点文件保存路径
        gradient_clipping=args.gradient_clipping,  # 是否进行梯度裁剪，用于防止梯度爆炸问题
        eval_data=data_valid,  # 用于评估模型性能的数据加载器
        eval_interval=args.eval_interval  # 每隔多少步进行一次模型性能评估
    ).run_loop()  # 调用 TrainLoop 类的 run_loop 方法会启动训练循环，并按照设定的参数进行模型训练


def create_argparser():
    defaults = dict(
        data_dir="",
        schedule_sampler="uniform",
        lr=1e-4,
        weight_decay=0.0,
        lr_anneal_steps=0,
        batch_size=1,
        microbatch=-1,  # -1 disables microbatches
        ema_rate="0.9999",  # comma-separated list of EMA values
        log_interval=50,
        save_interval=50000,
        resume_checkpoint="",
        use_fp16=False,
        fp16_scale_growth=1e-3,
        seed=101,
        gradient_clipping=-1.0,
        eval_interval=2000,
        checkpoint_path='diff_models'
    )
    text_defaults = dict(modality='text',
                         dataset_name='wikitext',
                         dataset_config_name='wikitext-2-raw-v1',
                         config='diffusion_lm/synthetic_data/configs/emnlp2020/experiments/difflm_seed0_m3_k128_trainc20000.yaml',
                         model_name_or_path='predictability/diff_models/compress_e=5_b=60_m=gpt2_wikitext-103-raw-v1_None',
                         experiment='gpt2_pre_compress', model_arch='conv-unet',
                         roc_train='diffusion_lm/ROCstory',  # 'diffusion_lm/ROCstory/ROCstory17.csv',
                         wiki_train='diffusion_lm/simple_wiki/data.v1.split/simple.training.txt',
                         e2e_train='e2e_data',
                         yelp_train='diffusion_lm/yelpnlg-resources/yelpnlg-corpus',
                         commonGen_train='diffusion_lm/common-gen/commongen_data',
                         emb_scale_factor=1.0, noise_level=0.0, cache_mode='no', use_bert_tokenizer='no',
                         padding_mode='block',
                         preprocessing_num_workers=1)
    defaults.update(model_and_diffusion_defaults())
    defaults.update(text_defaults)
    parser = argparse.ArgumentParser()
    add_dict_to_argparser(parser, defaults)
    return parser


if __name__ == "__main__":
    if torch.cuda.is_available():
        # Set the current GPU device to GPU 7
        print("239GPU is available.")
        torch.cuda.device(6)
        device_idx = torch.cuda.current_device()
        device_name = torch.cuda.get_device_name(device_idx)
        print(f"Currently using GPU {device_idx}: {device_name}")
    else:
        print("239GPU is not available.")
    main()

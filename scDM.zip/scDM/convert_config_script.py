# 该类用于将生成的training_args.bin文件转换为json文件

import torch
import json

# training_args_bin_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/training_args.bin"
# output_json_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/training_args.json"
#training_args_bin_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-24950/training_args.bin"
#output_json_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-24950/training_args.json"
# /icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-24950
# training_args_bin_path ="/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-24950/training_args.bin"
# output_json_path ="/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-24950/training_args.json"
training_args_bin_path ="/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=1_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-4150/training_args.bin"
output_json_path ="/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=1_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/checkpoint-4150/training_args.json"
def convert_training_args_to_json(bin_path, json_path):
    training_args = torch.load(bin_path)

    # Helper function to handle non-serializable objects
    def convert_to_serializable(obj):
        if isinstance(obj, torch.optim.Optimizer):
            return str(obj)
        elif hasattr(obj, "__dict__"):
            return obj.__dict__
        else:
            return str(obj)

    with open(json_path, "w") as json_file:
        json.dump(training_args.__dict__, json_file, indent=2, default=convert_to_serializable)

if __name__ == "__main__":
    convert_training_args_to_json(training_args_bin_path, output_json_path)

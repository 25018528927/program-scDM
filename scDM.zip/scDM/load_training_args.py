# convert_config
import os
import pickle
import json

def convert_config(config_file, output_file):
    with open(config_file, "rb") as f:
        config_data = pickle.load(f)

    with open(output_file, "w") as f:
        json.dump(config_data, f, indent=2)

if __name__ == "__main__":
    config_file_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/e2e-tgt-tree_e=6_b=10_m=bert-base-uncased_wikitext-103-raw-v1_101_wp_None/training_args.bin"
    output_file_path = "/icislab/volume1/yuhanlei/project/Diffusion-LM-mainV2/classifier_models/training_args.json"

    convert_config(config_file_path, output_file_path)






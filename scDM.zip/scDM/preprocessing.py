# import umap
# import numpy as np
# import matplotlib.pyplot as plt


# 上面被注释掉的代码是分开画嵌入图；下面是合到一起

import umap
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# real_protein_data = pd.read_excel('/Users/yuhanlei/Desktop/处理下机数据/UMAP图中需要的真实值蛋白矩阵.xlsx')
# predicted_protein_data = pd.read_excel('/Users/yuhanlei/Desktop/处理下机数据/UMAP图中需要的预测值.xlsx')

umap_both = umap.UMAP(n_neighbors=10, min_dist=0.1, n_components=2)

all_protein_data = np.vstack([real_protein_data, predicted_protein_data])

umap_both_embedding = umap_both.fit_transform(all_protein_data)

plt.figure(figsize=(8, 6))
plt.scatter(umap_both_embedding[:len(real_protein_data), 0], umap_both_embedding[:len(real_protein_data), 1], c='turquoise', marker='o', label='Real Protein Data',s=1)
plt.scatter(umap_both_embedding[len(real_protein_data):, 0], umap_both_embedding[len(real_protein_data):, 1], c='gold', marker='o', label='Predicted Protein Data',s=1)
plt.title('UMAP between the true and predicted values for the MALT dataset')
plt.xlabel('UMAP1')
plt.ylabel('UMAP2')

plt.xticks([])
plt.yticks([])
plt.legend()
plt.savefig("/Users/yuhanlei/Desktop/嵌入23-11-30.png", dpi=600,transparent=True)
plt.show()
import re
import json

# 读取文本文件
with open('/Users/yuhanlei/Desktop/处理下机数据/PBMC/CD80/src1_test.txt', 'r') as file:
    data = file.read()


lines = data.split('\n')
result = []

for line in lines:
    if line:
        values = re.findall(r"-?\d+\.\d+", line)
        row = ["PC1", "PC2", "PC3", "PC4", "PC5", ":"]
        row.extend(values)
        result.append(row)

result_strings = [str(row) for row in result]

with open('/Users/yuhanlei/Desktop/处理下机数据/PBMC/CD80/target_attribute.json', 'w') as json_file:
    json.dump(result, json_file, indent=2)


import pandas as pd
from sklearn.decomposition import PCA

file_path = "/Users/yuhanlei/Desktop/处理下机数据/癌细胞药物治疗/转录组数据仅数值.xlsx"
df = pd.read_excel(file_path)

data_transposed = df.transpose()

gene_expression = data_transposed.iloc[:, :]

pca = PCA(n_components=5)
reduced_data = pca.fit_transform(gene_expression)

# 创建一个新DataFrame，包含细胞名称和降维后的数据
reduced_data_df = pd.DataFrame(reduced_data, columns=['PC1', 'PC2', 'PC3', 'PC4', 'PC5'])

# 保存降维后的数据到新文件
reduced_data_df.to_excel('/Users/yuhanlei/Desktop/处理下机数据/癌细胞药物治疗/reduced5_data22.xlsx', index=False)